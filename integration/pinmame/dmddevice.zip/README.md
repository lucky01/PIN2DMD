# PINMAME PIN2DMD DmdDevice.dll driver 

DmdDevice.dll is for standalone use with a real PIN2DMD device. Any other use is forbidden.
Depending on wether you have VPinMame.dll or VPinMame64.dll installed you need to install the contents of x86 or x64 folder in the zip package.
For installation just copy the contents of the folder file to your vpinmame installation folder. You may be asked to overwrite a previous installation of dmddevice.dll.

