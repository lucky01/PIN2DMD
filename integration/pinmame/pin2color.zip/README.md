# PINMAME Pin2Color.dll plugin for freezy dmd-extensions

The Pin2Color.dll is for usage as a plugin DLL for freezy dmd-extensions.
Depending on wether you have VPinMame.dll or VPinMame64.dll installed you need to install the contents of x86 or x64 folder in the zip package.
For installation just copy the contents of the zip file to your vpinmame installation folder. You may be asked to overwrite a previous installation of pin2color.dll.
The usage of this DLL plugin is only allowed with PIN2DMD approved devices. Adding color support to any other devices is forbidden.

For full installation instructions and installation support please go here 
https://vpuniverse.com/forums/topic/7504-new-version-dmd-extensions-with-pin2dmd-coloring-plugin-and-pac-file-support/





